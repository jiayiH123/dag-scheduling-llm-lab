from __future__ import annotations

from typing import Any, Dict, Mapping, Sequence, Tuple

from ..models import ExecutionPlan, ExecutionTask, GraphSpec, Worker, is_llm_engine, llm_model_key
from .topo_utils import default_worker_filter, filtered_dependencies, topological_order


def build_min_switch_plan(
    graph: GraphSpec,
    workers: Mapping[str, Worker],
    *,
    dependencies: Mapping[str, Sequence[str]] | None = None,
    schedulable_ids: Sequence[str] | None = None,
    node_worker_options: Mapping[str, Sequence[str]] | None = None,
    plan_choices: Mapping[tuple[str, str], Sequence] | None = None,
    selected_query_plans: Mapping[tuple[str, str], Any] | None = None,
    metadata: Mapping[str, Any] | None = None,
) -> ExecutionPlan:
    """Cache-agnostic, model-switch-minimizing baseline."""
    worker_ids = tuple(sorted(workers))
    if not worker_ids:
        raise ValueError("MinSwitch scheduler requires at least one worker.")

    schedulable = tuple(
        sorted(
            schedulable_ids
            if schedulable_ids is not None
            else (nid for nid, node in graph.nodes.items() if node.type != "input")
        )
    )
    filtered_deps = filtered_dependencies(graph, schedulable, dependencies)
    order = topological_order(filtered_deps, schedulable)

    options: Dict[str, Tuple[str, ...]] = {}
    if node_worker_options is not None:
        for node_id in schedulable:
            opts = tuple(node_worker_options.get(node_id, ()))
            if not opts:
                raise RuntimeError(f"No eligible workers for node '{node_id}'")
            options[node_id] = opts
    else:
        for node_id in schedulable:
            node = graph.nodes[node_id]
            eligible = tuple(wid for wid, worker in workers.items() if default_worker_filter(node, worker))
            if not eligible:
                raise RuntimeError(f"No eligible workers for node '{node_id}'")
            options[node_id] = eligible

    last_model: Dict[str, str | None] = {wid: None for wid in worker_ids}
    load: Dict[str, int] = {wid: 0 for wid in worker_ids}
    tasks: list[ExecutionTask] = []
    total_workers = len(worker_ids)

    for idx, node_id in enumerate(order):
        node = graph.nodes[node_id]
        eligible = options[node_id]
        chosen: str | None = None

        if is_llm_engine(node.engine):
            same = [wid for wid in eligible if last_model.get(wid) == llm_model_key(node)]
            if same:
                chosen = min(same, key=lambda wid: (load.get(wid, 0), wid))
            else:
                empty = [wid for wid in eligible if last_model.get(wid) is None]
                if empty:
                    chosen = min(empty, key=lambda wid: (load.get(wid, 0), wid))

        if chosen is None:
            start = idx % total_workers
            for offset in range(total_workers):
                cand = worker_ids[(start + offset) % total_workers]
                if cand in eligible:
                    chosen = cand
                    break
        if chosen is None:
            chosen = eligible[0]

        load[chosen] = load.get(chosen, 0) + 1
        if is_llm_engine(node.engine):
            last_model[chosen] = llm_model_key(node) or last_model.get(chosen)
        epoch = idx // total_workers
        tasks.append(
            ExecutionTask(
                node_id=node_id,
                worker_id=chosen,
                dependencies=filtered_deps.get(node_id, ()),
                epoch=epoch,
            )
        )

    return ExecutionPlan(
        workers=dict(workers),
        tasks=tuple(tasks),
        query_plans=plan_choices or {},
        selected_query_plans=selected_query_plans or {},
        metadata=dict(metadata or {}),
    )
